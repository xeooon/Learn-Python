# !/usr/bin/env python
# -*- encoding:utf-8 -*-
# __author__ = "Xeon"
# Email: Xeon@xeon.org.cn
""""""

# ---------------------------- 此部分是 配置文件 ----------------------------
# 这里的配置文件需要写绝对路径，r的意思是转义

DB_PATH = r'/Users/xeon/Documents/Python/python24期/Python Project/Python24/day07/blog/register'
LOG_PATH = r'/Users/xeon/Documents/Python/python24期/Python Project/Python24/day07/blog/log/access.log'
